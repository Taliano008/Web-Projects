from django.urls import path
from .views import MaterialListView, MaterialCreateView, MaterialUpdateView, MaterialDeleteView,MaterialDetailView, RegisterPage
from django.conf import settings


from django.contrib.auth import views as auth_views
from .views import logout_view
from django.conf.urls.static import static


urlpatterns = [
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('logout/', logout_view, name='logout'),
    path('', MaterialListView.as_view(), name='material-list'),
    path('add/', MaterialCreateView.as_view(), name='material-add'),
    path('edit/<int:pk>/', MaterialUpdateView.as_view(), name='material-edit'),
    path('delete/<int:pk>/', MaterialDeleteView.as_view(), name='material-delete'),
    path('detail/<int:pk>/', MaterialDetailView.as_view(), name='material-detail')
    ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
