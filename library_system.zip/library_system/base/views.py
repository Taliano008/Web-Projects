from django.views.generic import ListView, CreateView, UpdateView, DeleteView,DetailView
from django.urls import reverse_lazy
from django.shortcuts import redirect
from django.views.generic.edit import FormView

from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login  
from django.contrib.auth import logout


from .models import Material


class customLoginView(LoginView):
    template_name = 'registration/login.html'
    redirect_authenticated_user = True
    def get_success_url(self):
        return reverse_lazy('material-list')
    

def logout_view(request):
    logout(request)
    return redirect('login') 

class RegisterPage(FormView):
    template_name = 'registration/register.html'
    form_class = UserCreationForm
    success_url = reverse_lazy('material-list')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super().form_valid(form)

    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect('material-list')
        return super().dispatch(request, *args, **kwargs)

class MaterialListView(LoginRequiredMixin, ListView):
    model = Material
    template_name = 'base/material_list.html'
    context_object_name = 'materials'
    paginate_by = 8

    def get_queryset(self):
        queryset = super().get_queryset()
        year = self.request.GET.get('year')
        semester = self.request.GET.get('semester')
        material_type = self.request.GET.get('type')
        if year:
            queryset = queryset.filter(year=year)
        if semester:
            queryset = queryset.filter(semester=semester)
        if material_type:
            queryset = queryset.filter(material_type=material_type)
        return queryset
    #
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['years'] = Material.objects.values_list('year', flat=True).distinct()#
        context['semesters'] = Material.objects.values_list('semester', flat=True).distinct()
        context['material_types'] = Material.objects.values_list('material_type', flat=True).distinct()
        context['count'] = context['materials'].count()
        #search functionality
        search_input = self.request.GET.get('search-area') or ''
        if search_input:
            context['materials'] = context['materials'].filter(title__startswith=search_input)
        context['search_input'] = search_input
        
        # Preserve GET parameters (for filtering while paginating)
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            del query_params['page']
        context['query_params'] = query_params.urlencode()

        return context

class MaterialDetailView(LoginRequiredMixin, DetailView):
    model = Material
    template_name = 'base/material_detail.html'
    context_object_name = 'material'
    
class MaterialCreateView(LoginRequiredMixin, CreateView):
    model = Material
    fields = ['title', 'year', 'semester', 'material_type', 'file']
    template_name = 'base/material_form.html'
    success_url = reverse_lazy('material-list')

    def form_valid(self, form):
        form.instance.uploaded_by = self.request.user
        return super().form_valid(form)

class MaterialUpdateView(LoginRequiredMixin, UpdateView):
    model = Material
    fields = ['title', 'year', 'semester', 'material_type', 'file']
    template_name = 'base/material_form.html'
    success_url = reverse_lazy('material-list')

class MaterialDeleteView(LoginRequiredMixin, DeleteView):
    model = Material
    context_object_name = 'material'
    template_name = 'base/material_confirm_delete.html'
    success_url = reverse_lazy('material-list')
