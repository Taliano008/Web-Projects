from django.db import models
from django.contrib.auth.models import User

class Material(models.Model):
    TYPE_CHOICES = [
        ('CAT', 'CAT'),
        ('Exam', 'Exam'),
    ]

    year = models.PositiveSmallIntegerField(choices=[(i, f'Year {i}') for i in range(1, 5)])
    semester = models.PositiveSmallIntegerField(choices=[(1, 'Semester 1'), (2, 'Semester 2')])
    material_type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to='materials/')
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
